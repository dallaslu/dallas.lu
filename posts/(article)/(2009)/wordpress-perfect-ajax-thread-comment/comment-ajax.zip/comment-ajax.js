jQuery(document).ready(function(){
$("#commentform").submit(function(){//comment-form 为评论表单 ID
	pass = true;
	
	var $text = $('#comment'); //评论内容输入框
	var $form = $('#commentform');
	var $respond = $('#respond'); //整个评论输入区，包括表单、提示什么的
	var $submit = $('#submit'); //提交按钮
	
	//进度条，请自行在 CSS 中设定样式
	var loading = '<div id="comment-load" class="loading" style="display:none"></div>';  
 
	/*
	 * 简单验证表单数据
	 */
	$("input[aria-required=true]").each(function(){
		if(this.value == "") {
			this.focus();
			pass = false;
		};
	});
	if (pass && $text.val()==""){
			$text.focus();
			pass = false;
		};
 
	//开始处理评论
	if (pass){
		jQuery.ajax({
			url: 'http://localhost/wordpress/comments-ajax.php', //绝对路径
			data: $form.serialize(),  
			type: 'POST',
			beforeSend:function(){ //发送数据前
				$submit.after(loading);
				$submit.hide();
				$('#comment-load').show('slow');
				$form.find('input,textarea').attr("disabled",true); //表单组件设置为不可用
			},
			error:function(request){ //出错的情况
				alert(request.responseText); //我比较懒，直接蹦个对话框
				$('#comment-load').remove();
				$submit.show();
				$form.find('input').removeAttr('disabled'); //表单可用
			},
			success:function(data){ //评论发表成功
				$('#comment-load').hide("slow").remove(); //干掉进度条
				$submit.show();
				$text.val(''); //清空文本域中评论内容
				var $parent = $respond.parent(); //评论区父元素
				var $child_list; //评论列表
				if(!$('#commentlist').length){ //没有评论则加个列表先。模板中已给了个ID
					$respond.before('<ol class="commentlist" id="commentlist"></ol>');
				}
				if($parent.attr('id')=='content'){ //父元素若是main(与我模板有关)
					$child_list = $('#commentlist');
				}else{ //回复他人评论（嵌套）的情况
					if(!$parent.find('ul.children').length){ //还没有子评论则添加个列表先
						$respond.before('<ul class="children"></ul>');
 
						// class 添加 parent 值。WP默认就是这么干的
						$parent.addClass('parent'); 
					}
					$child_list = $parent.find('ul.children:first');
				}
				$child_list.append(data); //新评论终于出来了
 
				//处理评论计数。这个 comment-num 已经事先放好。
				if($('#comment-num').length){
					$('#comment-num').text(parseInt($('#comment-num').text())+1);
				}else{
					$('#comments').html('<span id="comment-num">1</span> 条');
				}
				//
				var $newc = $child_list.find('li:last');
					if($newc.prev().length){
						var $c = $newc.prev();
						if( $c.hasClass('even')){
							$newc.removeClass('even').addClass('odd alt');
						}
						if( $c.hasClass('thread-even')){
							$newc.removeClass('thead-even').addClass('thread-odd thread-alt');
						}
					}
				$newc.slideDown('slow',function(){
 
					//slideDown 过后 display 值为 block，影响了评论样式。
					$newc.css('display',''); 
				});
				//表单恢复可用
				setTimeout(function(){
						$form.find('input,textarea').removeAttr('disabled');
					}, 3000); 
			}
		});
	}
	return false;
});
});
