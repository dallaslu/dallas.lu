(function(){
	var $ = mini;
	var defaultOption = {
		"nav":"#banner-tab-nav",
		"content":"#banner-tab-content",
		"trigger":"click mouseover"
	};
	
	function jstab( params ){
		var options = parseOption(params);
		bindEvent(options);
	}
	
	function bindEvent( options ){
		var as = $(options.nav+" li a");
		
		for( var i in as ){
			var hash = as[i].href.split("#")[1];
			var targetContent = $("#"+hash)[0];
			
			var handler = createHandler( as[i].parentNode,targetContent,options );
			if( /click/.test(options.trigger) ){
				as[i].onclick = handler;
			}
			
			if( /mouseover/.test(options.trigger) ){
				as[i].onmouseover = handler;
			}
			
			as[i].onfocus = function(){
				this.blur();
			}
		}
	}
	
	function createHandler(targetNav, targetContent,options ){
		var contents = $(options.content+" li.jstab-content-item");
		var navs = $(options.nav+" li.jstab-nav-item");
		
		return function handle(){
			for( var i in navs ){
				removeClass(navs[i],"jstab-nav-current-item");
			}
			addClass(targetNav,"jstab-nav-current-item");

			for( var i in contents ){
				removeClass(contents[i],"jstab-content-current-item");
			}
			addClass(targetContent,"jstab-content-current-item");
			
			return false;
		}
	}
	
	function parseOption( params ){
		if ( params ){
			var options = {};
			
			for(var key in defaultOption){
				options[key] = params[key]?params[key]:defaultOption[key];
			}
			
			return options;
		}else{
			return defaultOption;
		}
	}
	
	function addClass( element, className ){
		if (!hasClass(element,className)) 
			element.className += " "+className;
	}
	
	function removeClass( element, className ){
		if (hasClass(element,className)) {
			var reg = new RegExp('(\\s|^)'+className+'(\\s|$)');
			element.className = element.className.replace(reg,' ');
		}
	}
	
	function hasClass( element, className ){
		return element.className.match(new RegExp('(\\s|^)'+className+'(\\s|$)'));
	}
	
	window["jstab"] = jstab;
})();